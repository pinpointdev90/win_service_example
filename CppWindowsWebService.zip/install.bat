@echo off
echo Run this file from an Administrator Command Prompt.
CppWindowsWebService.exe install
pause
