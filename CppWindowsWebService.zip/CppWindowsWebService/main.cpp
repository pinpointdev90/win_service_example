#include "Service.h"

#include <windows.h>
#include <iostream>
#include <string>

int wmain(int argc, wchar_t* argv[])
{
    if (argc >= 2)
    {
        std::wstring command = argv[1];

        if (command == L"install")
        {
            if (WindowsService::Install())
            {
                std::wcout << L"Service installed successfully.\n";
                return 0;
            }

            std::wcerr << L"Failed to install service. Error: "
                       << GetLastError() << L"\n";
            return 1;
        }

        if (command == L"uninstall")
        {
            if (WindowsService::Uninstall())
            {
                std::wcout << L"Service uninstalled successfully.\n";
                return 0;
            }

            std::wcerr << L"Failed to uninstall service. Error: "
                       << GetLastError() << L"\n";
            return 1;
        }
    }

    WindowsService::Run();
    return 0;
}
