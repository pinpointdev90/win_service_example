#include "HttpServer.h"

#include <string>
#include <cstring>

HttpServer::HttpServer(unsigned short port)
    : port_(port),
      serverSocket_(INVALID_SOCKET),
      running_(false)
{
}

HttpServer::~HttpServer()
{
    Stop();
}

bool HttpServer::Start()
{
    WSADATA wsaData{};

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
        return false;

    serverSocket_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (serverSocket_ == INVALID_SOCKET)
    {
        WSACleanup();
        return false;
    }

    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(port_);

    if (bind(
        serverSocket_,
        reinterpret_cast<sockaddr*>(&address),
        sizeof(address)) == SOCKET_ERROR)
    {
        closesocket(serverSocket_);
        serverSocket_ = INVALID_SOCKET;
        WSACleanup();
        return false;
    }

    if (listen(serverSocket_, SOMAXCONN) == SOCKET_ERROR)
    {
        closesocket(serverSocket_);
        serverSocket_ = INVALID_SOCKET;
        WSACleanup();
        return false;
    }

    running_ = true;
    acceptThread_ = std::thread(&HttpServer::AcceptLoop, this);

    return true;
}

void HttpServer::Stop()
{
    if (!running_.exchange(false))
        return;

    if (serverSocket_ != INVALID_SOCKET)
    {
        shutdown(serverSocket_, SD_BOTH);
        closesocket(serverSocket_);
        serverSocket_ = INVALID_SOCKET;
    }

    if (acceptThread_.joinable())
        acceptThread_.join();

    WSACleanup();
}

void HttpServer::AcceptLoop()
{
    while (running_)
    {
        SOCKET client = accept(serverSocket_, nullptr, nullptr);

        if (client == INVALID_SOCKET)
        {
            if (!running_)
                break;
            continue;
        }

        std::thread(&HttpServer::HandleClient, this, client).detach();
    }
}

void HttpServer::HandleClient(SOCKET client)
{
    char buffer[4096];

    int received = recv(
        client,
        buffer,
        sizeof(buffer) - 1,
        0
    );

    if (received <= 0)
    {
        closesocket(client);
        return;
    }

    buffer[received] = '\0';

    const char* body =
        "Hello from C++ Windows Service!\r\n";

    std::string response =
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/plain\r\n"
        "Content-Length: " +
        std::to_string(std::strlen(body)) +
        "\r\n"
        "Connection: close\r\n"
        "\r\n" +
        std::string(body);

    send(
        client,
        response.c_str(),
        static_cast<int>(response.size()),
        0
    );

    shutdown(client, SD_BOTH);
    closesocket(client);
}
