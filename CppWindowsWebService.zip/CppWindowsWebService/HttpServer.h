#pragma once

#include <winsock2.h>
#include <windows.h>

#include <atomic>
#include <thread>

#pragma comment(lib, "Ws2_32.lib")

class HttpServer
{
public:
    explicit HttpServer(unsigned short port);
    ~HttpServer();

    bool Start();
    void Stop();

private:
    void AcceptLoop();
    void HandleClient(SOCKET client);

private:
    unsigned short port_;
    SOCKET serverSocket_;
    std::atomic<bool> running_;
    std::thread acceptThread_;
};
