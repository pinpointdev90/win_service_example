#include "Service.h"
#include "HttpServer.h"

#include <windows.h>
#include <iostream>

SERVICE_STATUS_HANDLE WindowsService::serviceStatusHandle = nullptr;
SERVICE_STATUS WindowsService::serviceStatus = {};
HANDLE WindowsService::stopEvent = nullptr;

static const wchar_t* SERVICE_NAME = L"CppWebService";

void WindowsService::Run()
{
    SERVICE_TABLE_ENTRYW serviceTable[] =
    {
        { const_cast<LPWSTR>(SERVICE_NAME), ServiceMain },
        { nullptr, nullptr }
    };

    if (!StartServiceCtrlDispatcherW(serviceTable))
    {
        DWORD error = GetLastError();

        if (error == ERROR_FAILED_SERVICE_CONTROLLER_CONNECT)
        {
            std::wcout << L"Running in console mode.\n";

            HttpServer server(8080);
            if (!server.Start())
            {
                std::wcerr << L"Failed to start HTTP server.\n";
                return;
            }

            std::wcout << L"HTTP server running on http://localhost:8080\n";
            std::wcout << L"Press ENTER to stop.\n";

            std::wstring line;
            std::getline(std::wcin, line);
            server.Stop();
        }
    }
}

void WINAPI WindowsService::ServiceMain(DWORD argc, LPWSTR* argv)
{
    UNREFERENCED_PARAMETER(argc);
    UNREFERENCED_PARAMETER(argv);

    serviceStatusHandle =
        RegisterServiceCtrlHandlerExW(SERVICE_NAME, ServiceHandler, nullptr);

    if (!serviceStatusHandle)
        return;

    ZeroMemory(&serviceStatus, sizeof(serviceStatus));
    serviceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    serviceStatus.dwCurrentState = SERVICE_START_PENDING;
    serviceStatus.dwControlsAccepted = 0;
    serviceStatus.dwWin32ExitCode = NO_ERROR;
    serviceStatus.dwCheckPoint = 0;
    serviceStatus.dwWaitHint = 3000;

    SetServiceStatus(SERVICE_START_PENDING, NO_ERROR, 3000);

    stopEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);

    if (!stopEvent)
    {
        SetServiceStatus(SERVICE_STOPPED, GetLastError());
        return;
    }

    HttpServer server(8080);

    if (!server.Start())
    {
        SetServiceStatus(SERVICE_STOPPED, GetLastError());
        CloseHandle(stopEvent);
        stopEvent = nullptr;
        return;
    }

    SetServiceStatus(SERVICE_RUNNING);

    WaitForSingleObject(stopEvent, INFINITE);

    SetServiceStatus(SERVICE_STOP_PENDING, NO_ERROR, 5000);
    server.Stop();

    CloseHandle(stopEvent);
    stopEvent = nullptr;

    SetServiceStatus(SERVICE_STOPPED);
}

DWORD WINAPI WindowsService::ServiceHandler(
    DWORD control,
    DWORD eventType,
    LPVOID eventData,
    LPVOID context)
{
    UNREFERENCED_PARAMETER(eventType);
    UNREFERENCED_PARAMETER(eventData);
    UNREFERENCED_PARAMETER(context);

    switch (control)
    {
    case SERVICE_CONTROL_STOP:
        if (serviceStatus.dwCurrentState == SERVICE_RUNNING)
        {
            SetServiceStatus(SERVICE_STOP_PENDING, NO_ERROR, 5000);

            if (stopEvent)
                SetEvent(stopEvent);
        }
        break;

    case SERVICE_CONTROL_INTERROGATE:
        break;

    default:
        break;
    }

    return NO_ERROR;
}

void WindowsService::SetServiceStatus(
    DWORD currentState,
    DWORD win32ExitCode,
    DWORD waitHint)
{
    static DWORD checkpoint = 1;

    serviceStatus.dwCurrentState = currentState;
    serviceStatus.dwWin32ExitCode = win32ExitCode;
    serviceStatus.dwWaitHint = waitHint;

    if (currentState == SERVICE_START_PENDING ||
        currentState == SERVICE_STOP_PENDING)
    {
        serviceStatus.dwControlsAccepted = 0;
        serviceStatus.dwCheckPoint = checkpoint++;
    }
    else if (currentState == SERVICE_RUNNING)
    {
        serviceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
        serviceStatus.dwCheckPoint = 0;
    }
    else
    {
        serviceStatus.dwControlsAccepted = 0;
        serviceStatus.dwCheckPoint = 0;
    }

    ::SetServiceStatus(serviceStatusHandle, &serviceStatus);
}

bool WindowsService::Install()
{
    wchar_t path[MAX_PATH];

    if (!GetModuleFileNameW(nullptr, path, MAX_PATH))
        return false;

    SC_HANDLE scm = OpenSCManagerW(
        nullptr,
        nullptr,
        SC_MANAGER_CREATE_SERVICE
    );

    if (!scm)
        return false;

    SC_HANDLE service = CreateServiceW(
        scm,
        SERVICE_NAME,
        SERVICE_NAME,
        SERVICE_ALL_ACCESS,
        SERVICE_WIN32_OWN_PROCESS,
        SERVICE_AUTO_START,
        SERVICE_ERROR_NORMAL,
        path,
        nullptr,
        nullptr,
        nullptr,
        L"LocalSystem",
        nullptr
    );

    if (!service)
    {
        CloseServiceHandle(scm);
        return false;
    }

    SC_ACTION actions[3]{};
    actions[0].Type = SC_ACTION_RESTART;
    actions[0].Delay = 5000;
    actions[1].Type = SC_ACTION_RESTART;
    actions[1].Delay = 10000;
    actions[2].Type = SC_ACTION_RESTART;
    actions[2].Delay = 30000;

    SERVICE_FAILURE_ACTIONSW failureActions{};
    failureActions.dwResetPeriod = 86400;
    failureActions.cActions = 3;
    failureActions.lpsaActions = actions;

    ChangeServiceConfig2W(
        service,
        SERVICE_CONFIG_FAILURE_ACTIONS,
        &failureActions
    );

    CloseServiceHandle(service);
    CloseServiceHandle(scm);

    return true;
}

bool WindowsService::Uninstall()
{
    SC_HANDLE scm = OpenSCManagerW(
        nullptr,
        nullptr,
        SC_MANAGER_CONNECT
    );

    if (!scm)
        return false;

    SC_HANDLE service = OpenServiceW(
        scm,
        SERVICE_STOP | SERVICE_QUERY_STATUS | DELETE
    );

    if (!service)
    {
        CloseServiceHandle(scm);
        return false;
    }

    SERVICE_STATUS status{};
    ControlService(service, SERVICE_CONTROL_STOP, &status);

    bool result = DeleteService(service);

    CloseServiceHandle(service);
    CloseServiceHandle(scm);

    return result;
}
