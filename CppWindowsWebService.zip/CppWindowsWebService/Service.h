#pragma once

#include <windows.h>

class WindowsService
{
public:
    static bool Install();
    static bool Uninstall();
    static void Run();

private:
    static void WINAPI ServiceMain(DWORD argc, LPWSTR* argv);
    static DWORD WINAPI ServiceHandler(
        DWORD control,
        DWORD eventType,
        LPVOID eventData,
        LPVOID context
    );

    static void SetServiceStatus(
        DWORD currentState,
        DWORD win32ExitCode = NO_ERROR,
        DWORD waitHint = 0
    );

    static SERVICE_STATUS_HANDLE serviceStatusHandle;
    static SERVICE_STATUS serviceStatus;
    static HANDLE stopEvent;
};
